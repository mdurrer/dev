-----------------------------------------------------------------------------
			      /////////////////
	                      //////////////////
        	              ////          ////
	               	      ////   ///////////
	                      ////  ///////////
                              ////  ////
                              ////  ///////////
                              ////   //////////
  	     	   	
  			   www.revival-studios.com
-----------------------------------------------------------------------------
Title		:	HexCoder
Author		:	Martijn Wenting / Revival Studios
Genre		:	Tool
System		:	Windows commandline 
Date		:	11/09/2010 
Product ID	:	RS-AP000
-----------------------------------------------------------------------------

All the contents of this package are (c)Copyright 2010 Revival Studios.

The contents of the package may only be spread in its original form, and may not be
published or distributed otherwise without the written permission of the authors.

Description:
------------
HexCoder is a very small commandline tile that allows you edit hex-files from scratch.
I needed a simple tool that allowed me to type in hex-codes and create a binary, so i could convert some listing from old magazines and manuals. However i couldn't find any tool that did that, so i decided to write one myself.

Running the Tool:
-----------------
Usage: HEXCODER <output.bin> <startaddress>
When you don't specify a startaddress, it will take $200.

You can now type in hexcodes, in 16-bit pairs. 
When you are finished, type in the hexcode "DEAD" and the program will save the binary and close down.

Distribution:
-------------
This package can be freely distributed in its original form.
If you would like to include this game in your rom package, please let me know.

Watch out for more releases soon!


	Martijn Wenting / Revival Studios

