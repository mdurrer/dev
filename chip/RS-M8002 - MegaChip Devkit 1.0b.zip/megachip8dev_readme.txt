
Megachip8 development kit, v1.0b

Super/Mega/Chip-48 Assembler V2.5 by Christian Egeberg (20/8/91).
MegaChip8-Assembler extensions by: Martijn Wenting / Revival Studios (08/07/2007)

All other tools by: Martijn Wenting / Revival Studios

The supplied example is a minimal game, with only the bare basics in place. 
The sources for the CHIP8/SuperChip version, and the MegaChip8 version are both supplied.

For easy building (build.bat and buildmega.bat), install the package in a subdirectory of the MegaChip emulator (e.g. <emulatorpath>\megachip8dev).


Enjoy!